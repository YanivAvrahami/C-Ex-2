﻿namespace B21_Ex02
{
    public enum eSymbol
    {
        X,
        O
    }
}
