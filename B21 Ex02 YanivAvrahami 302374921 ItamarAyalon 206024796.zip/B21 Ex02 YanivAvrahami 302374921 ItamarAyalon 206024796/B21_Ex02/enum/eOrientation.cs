﻿namespace B21_Ex02
{
    public enum eOrientation
    {
        Horizontal,
        Vertical,
        Decending,
        Ascending,
    }
}
