﻿namespace B21_Ex02
{
    public enum ePlayMode
    {
        SinglePlayer,
        MultiPlayer
    }
}
