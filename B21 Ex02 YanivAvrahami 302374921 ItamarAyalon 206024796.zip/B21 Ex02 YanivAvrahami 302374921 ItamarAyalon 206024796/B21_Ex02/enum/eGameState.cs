﻿namespace B21_Ex02
{
    public enum eGameState
    {
        InProgress,
        Win,
        Draw,
        Quit
    }
}
