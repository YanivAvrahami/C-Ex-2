﻿namespace B21_Ex02
{
    public class Player : BasePlayer
    {
        public Player(eSymbol i_Symbol, string i_Name)
            : base(i_Symbol, i_Name)
        {

        }
    }
}
