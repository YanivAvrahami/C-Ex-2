﻿namespace B21_Ex02
{
    class Program
    {
        public static void Main()
        {
            UI ui = new UI();
            ui.Run();
        }
    }
}
